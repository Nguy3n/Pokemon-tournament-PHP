<?php
echo "<div class='footer'>"
    ."<legend>HiOA Webprogrammering Vår 2016</legend>"
    ."</div>";
    
?>    