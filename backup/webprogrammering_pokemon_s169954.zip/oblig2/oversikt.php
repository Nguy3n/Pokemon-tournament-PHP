<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
  <title>Oversikt</title>
  <link href="css/main.css" rel="stylesheet">
</head>
<body>
  <nav id="nav01"></nav>
  <div id="hoved">
  <h1>Oversikt</h1>
  
  <h2><a href="kampene.php">Kampene</a></h2>
  <h2><a href="trenerne.php">Trenerne</a></h2>
  <h2><a href="arenaene.php">Arenaene</a></h2>
  <h2><a href="pokemon.php">Pokémonene</a></h2>
  
  
  </div>
  <footer id="foot01"></footer>
  <script src="js/script.js"></script>
</body>
</html>
