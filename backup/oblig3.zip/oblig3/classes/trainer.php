<?php
    Class trainer
    {
        public $pokemon1;
        public $pokemon2;
        public $pokemon3;
    }


?>
