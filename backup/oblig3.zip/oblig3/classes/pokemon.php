<?php
    Class pokemon
    {
        public $hp;
        
        public $attack1;
        public $attack2;
        public $attack3;
        public $attack4;
    }
?>