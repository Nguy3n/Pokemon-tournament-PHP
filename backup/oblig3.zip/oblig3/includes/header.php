<?php
echo "<div class='jumbotron'>"
    ."<div class='site-index wrapper'>"
    ."<h1>Pokemon tournament</h1>"
    ."</div></div>";
    
?>    