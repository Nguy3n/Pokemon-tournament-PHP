document.getElementById("foot01").innerHTML = "<p>&copy; " + new Date().getFullYear() +  " H&oslash;gskolen i Oslo og Akershus</p>";

document.getElementById("nav01").innerHTML = 
"<ul id='meny'>" + 
"<li><img src='images/pokedex.png'><a href='index.php'>Hovedsiden</a>|</li>" +
"<li><img src='images/center.png'><a href='oversikt.php'>Oversikt</a>|</li>" +
"<li><img src='images/ball.png'><a href='registrering.php'>Registrering</a>|</li>" +
"<li><img src='images/admin.gif'><a href='admin.php'>Admin</a></li>" +
    "</ul>";